<?php

namespace Laravel\Nova\Actions;

class DestructiveAction extends Action
{
    //
}
